<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="application/javascript" src="funciones.js"></script>
<script type="application/javascript" src="jquery-2.0.3.js"></script>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>View IP</title>
<style type="text/css">
	body,td,th {
	font-size: 14px;
	font-weight: bold;
}
</style>
</head>

<body bgcolor="#E8EEFF">
<h1 align="center"><strong>Verificar Mascara de Red: </strong></h1>
<p align="center">&nbsp;</p>
<center><form id="form1" name="form1" method="post" action="">
  <input type="text" name="IdSearch" id="IdSearch" />
  <input type="button" name="BSearch" id="BSearch" value="Search" onClick="JavaScript:consultarMask();" />
  
  <div id="main_content" name="main_content"> </div>
</form></center>
</body>
</html>
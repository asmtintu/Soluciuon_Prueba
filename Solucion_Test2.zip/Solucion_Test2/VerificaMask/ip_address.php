<?php
/** 
 * Get the number of netmask bits from a netmask in presentation format 
 * 
 * @param string $netmask Netmask in presentation format 
 *  
 * @return integer Number of mask bits 
 * @throws Exception 
 */ 
 
	function ipVersion($txt) {
		return strpos($txt, ":") === false ? 4 : 6;
	}
	
	function netmask2bitmask($maskData)
	{
		try
		{
			$numBits = 0;
			
			//Valid if mask is version 6 or 4
			$ipVersion = ipVersion($maskData);
			
			//Print mask data
			echo "<br><br>Mask Data IpV : ".$ipVersion."<br>";
			
			if($ipVersion==4);
			{
				$partNumber = explode(".", $maskData);
				foreach ($partNumber as $k) {					
					//Convert the decimal number to bit
					$bitNumber = decbin($k);	
					$numBits = $numBits + countBits($bitNumber);
				}
			}
			
			if($ipVersion==6)
			{				
				//Convert an IPv6 network, a bit string
				$maskData = createBitIpv6($maskData);
				
				$partNumber = explode(".", $maskData);
				foreach ($partNumber as $k) {
					$numBits = $numBits + countBits($k);
				}
			}
			
			return $numBits;
			} catch (Exception $e) {
			echo 'Exception cauhgt: ',  $e->getMessage(), "\n";
		}
	}
	
	//This function adds the bit in a string of numbers
	function countBits($num)
	{		
		$num_c = 0;
		while($num != 0){ 
			$num_c = $num_c + (bcmod($num,10));
			$num = bigintval(bcdiv($num,10,0));			
		}
		
		return $num_c;
	}
	
	//This function converts integers, large or small numbers
	function bigintval($value) {
		$value = trim($value);
		if (ctype_digit($value)) {
			return $value;
		}
		$value = preg_replace("/[^0-9](.*)$/", '', $value);
		if (ctype_digit($value)) {
			return $value;
		}
		return 0;
	}
	
	//This function converts an IPv6 network, a bit string
	function createBitIpv6($partMask)
	{
		$letter = array("0", "8", "c", "e", "f",":");
		$convert   = array("0000", "1000", "1100", "1110", "1111",".");
		
		$newMask = str_replace($letter, $convert, $partMask);
		return $newMask;
	}
	
	/************* MAIN *******************/
	//print netmask2bitmask('255.255.0.0') . "<br>";
	$data = $_POST['data'];
	
	print netmask2bitmask($data) . "<br>";

?>
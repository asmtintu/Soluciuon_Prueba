function cargarURL(contenedor, ajaxurl, datos) {
    $(contenedor).fadeOut(50, function () {
            // Completa el efecto fadeout, carga el nuevo contenido mientras se oculta
            $(contenedor).html('<img src="img/loader.gif" > cargando... </img>');
            $.ajax ( {
                type: 'post',
                url : ajaxurl,
                data : datos,
                success : function(htm) {
                    $(contenedor).html(htm);
                    $(contenedor).fadeIn();
                }
            });
        });
}

//############################################## Resultado ##############################################
function consultarMask(){
    var ajaxurl  = 'ip_address.php';
	var dataSearch = document.getElementById('IdSearch').value;
	//alert (dataSearch);
    var data_form = {
        data: dataSearch
    };
    cargarURL("#main_content", ajaxurl, data_form);
    
}
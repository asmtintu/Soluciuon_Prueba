<?php
include 'db.php';

class Host
{
    public static function getList($only_active = false)
    {
        static $result;
        
        if (!empty($result)) return $result;
        
		/** Fix 1: Se modifica query para que retorne el host que hacia falta, se encontro que el error se 
					debia a que la credencial 0 no existe en la tabla de credenciales, por ello se agrega un
					left join para que traiga los datos faltantes **/
        $stmt = "SELECT
                    hos.host_id,
                    hos.host_name,
                    hos.ip_address,
                    cre.username
                 FROM
                    hosts hos LEFT JOIN credentials cre ON hos.credential_id = cre.credential_id
                 WHERE
                    hos.deleted       = 0";
        if ($only_active === true) {
            $stmt .= " AND hos.active = 1";
        }
        
        $result = DB::getAll($stmt);
		
		/** Fix 2: Se agrega la cabecera para que la respuesta sea interpretada como JSON y no como XML **/
        header("Content-Type:text/javascript");
        return $result;
		
		
		//echo $result;
    }
}
?>
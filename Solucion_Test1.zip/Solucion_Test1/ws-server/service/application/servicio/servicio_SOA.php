<?php
	/**
	 * @author Asmed Tinoco
	 *
	 * 02/Oct/2015
	 *
	 * Archivo que genera de forma automática un WSDL a partir de la clase funcionesServicio
	 * utilizando Zend Framework
	 */
	
	// Se debe agregar al path el directorio raíz que contiene al framework
	// en este caso, si se respeto la estructura de directorio, es un nivel de directorio menos (../)
	set_include_path(get_include_path() . PATH_SEPARATOR . realpath(dirname(__FILE__) . "/../"));
	
	// Se incluye la clase a generar
	require_once('servicio.php');
	
	// Si en la url está presente la entrada ?wsdl
	if (strtolower($_SERVER['QUERY_STRING']) == "wsdl") {
		// Se incluye la clase AutoDiscover que es la encargada de generar en forma automática el WSDL
		require_once('Zend/Soap/AutoDiscover.php');
		
		$wsdl = new Zend_Soap_AutoDiscover();
		$wsdl->setClass('funcionesServicio');
		$wsdl->handle();
	}
	// Si no
	else {
		require_once('Zend/Soap/Server.php');
		
		$wsdl_url = sprintf('http://%s%s?wsdl', $_SERVER['HTTP_HOST'], $_SERVER['SCRIPT_NAME']);
		
		$server = new SoapServer($wsdl_url);
		$server->setClass('funcionesServicio');
		$server->handle();
	}
?>

<?php
	session_start();
	
	require_once ('../scripts/utilidades.php');
	require_once("../scripts/tmdb-api.php");	
	require_once("../scripts/printTable.php");
	/**
		* @author Asmed Tinoco
		*
		* 02/Oct/2015
		* 
		*
		* Clase de servicio web utilizando
		* Zend Framework
		*
	*/
	class funcionesServicio {
		
		/**
			* Retorna el resultado de busqueda en una cadena de string. 
			*
			* @param string $dataSearch dato a buscar
			* @return string
		*/
        function doSearch($dataSearch) {
			
			$to_return = 'false';
			//return $to_return;
			
			$apikey = "cc4b67c52acb514bdf4931f7cedfd12b";
			
			$tmdb = new TMDB($apikey, 'en', true);
			
			$dataS = $dataSearch;			
			$dataS = str_replace(" ", "+", $dataS);
			
			$persons = $tmdb->searchPerson($dataS);
			
			$idp = $persons[0]->getID();
			
			$url2 = "http://api.themoviedb.org/3/person/$idp?api_key=$apikey"; // Person Information
			$url3 = "http://api.themoviedb.org/3/person/$idp/movie_credits?api_key=$apikey"; //Movie Credits
			
			$content2 = file_get_contents($url2);
			$json2 = json_decode($content2, true);
			$array2 = new RecursiveArrayIterator($json2);
			$Iterator2 = new TableRII(new RecursiveArrayIterator($array2), RecursiveIteratorIterator::LEAVES_ONLY);
			foreach ($Iterator2 as $r => $b) {
				if(!is_array($b)){
					$to_return = $b. "\n";
				}
			}
			
			$content3 = file_get_contents($url3);
			$json3 = json_decode($content3, true);
			$array3 = new RecursiveArrayIterator($json3);
			$Iterator3 = new TableRII(new RecursiveArrayIterator($array3), RecursiveIteratorIterator::LEAVES_ONLY);
			foreach ($Iterator3 as $g => $h) {
				if(!is_array($h)){
					$to_return .= $h. "\n";
				}
			}
			
			return $to_return;
			
		}
		
		
	}
?>
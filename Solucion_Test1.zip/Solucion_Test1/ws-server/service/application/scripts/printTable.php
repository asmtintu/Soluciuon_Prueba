<?php

Class TableRII extends RecursiveIteratorIterator {
  private $parentKey = null;
  public function beginIteration() {
    echo '<table border=2><tr><th>Root</th><th>Description</th></tr>';
  }
  public function endIteration() {
    echo '</table>';
  }
  public function beginChildren() {
    echo '<tr><th>'. $this->parentKey .'</th><td><table border=1>';
  }
  public function endChildren() {
    echo '</table></td></tr>';
  }
  public function callHasChildren() {
    $bool = parent::callHasChildren();
    if($bool) {
      $this->parentKey = $this->key();
    }
    return $bool;
  }
  public function current() {
    return '<tr><th>'. $this->key() .'</th><td>'. parent::current() . '</td></tr>';
  }
}
?>